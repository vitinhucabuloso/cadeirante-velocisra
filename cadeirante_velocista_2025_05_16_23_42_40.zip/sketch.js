
let jogador;
let obstaculos = [];
let velocidade = 5;
let pontuacao = 0;
let gameOver = false;

function setup() {
  createCanvas(800, 400);
  jogador = {
    x: 100,
    y: 300,
    largura: 40,
    altura: 40,
    velocidadeY: 0,
    gravidade: 0.6,
    pulo: false,
    draw: function() {
      fill(0, 0, 255);
      rect(this.x, this.y, this.largura, this.altura, 5);
      fill(255);
      textSize(30);
      text("🦽", this.x + 5, this.y + 35);
    },
    update: function() {
      this.y += this.velocidadeY;
      this.velocidadeY += this.gravidade;
      if (this.y > 300) {
        this.y = 300;
        this.velocidadeY = 0;
        this.pulo = false;
      }
    },
    pular: function() {
      if (!this.pulo) {
        this.velocidadeY = -12;
        this.pulo = true;
      }
    }
  };
}

function draw() {
  if (gameOver) {
    telaGameOver();
    return;
  }
  
  background(135, 206, 235);
  fill(100);
  rect(0, 350, width, 50);
  
  // Prédios
  fill(70);
  rect(0, 200, 100, 150);
  rect(150, 150, 120, 200);
  rect(350, 180, 90, 170);
  
  jogador.draw();
  jogador.update();
  
  if (frameCount % 90 === 0) {
    obstaculos.push({
      x: width,
      y: 310,
      largura: 30,
      altura: 40,
      velocidade: velocidade,
      draw: function() {
        fill(255, 165, 0);
        rect(this.x, this.y, this.largura, this.altura);
        fill(0);
        text("🚧", this.x + 5, this.y + 35);
      },
      update: function() {
        this.x -= this.velocidade;
      }
    });
  }
  
  for (let i = obstaculos.length - 1; i >= 0; i--) {
    obstaculos[i].draw();
    obstaculos[i].update();
    
    if (obstaculos[i].x < -obstaculos[i].largura) {
      obstaculos.splice(i, 1);
      pontuacao++;
    }
    
    if (colisao(jogador, obstaculos[i])) {
      gameOver = true;
    }
  }
  
  if (frameCount % 500 === 0) {
    velocidade += 0.5;
  }
  
  fill(0);
  textSize(24);
  text(`Pontuação: ${pontuacao}`, 20, 30);
}

function colisao(jogador, obstaculo) {
  return (
    jogador.x + jogador.largura > obstaculo.x &&
    jogador.x < obstaculo.x + obstaculo.largura &&
    jogador.y + jogador.altura > obstaculo.y
  );
}

function telaGameOver() {
  background(0, 100);
  fill(255);
  textSize(48);
  textAlign(CENTER);
  text("⛔ FIM DE JOGO ⛔", width / 2, height / 2);
  textSize(24);
  text(`Pontuação: ${pontuacao}`, width / 2, height / 2 + 50);
  text("Pressione ESPAÇO", width / 2, height / 2 + 100);
}

function keyPressed() {
  if (key === ' ' && !gameOver) {
    jogador.pular();
  }
  if (key === ' ' && gameOver) {
    obstaculos = [];
    pontuacao = 0;
    velocidade = 5;
    gameOver = false;
  }
}